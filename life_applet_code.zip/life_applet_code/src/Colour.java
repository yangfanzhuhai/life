// enum for managing the basic three colours of the cells
// RED and GREEN cells are alive, GREY cells are dead
public enum Colour {
	RED, GREEN, GREY;
}
